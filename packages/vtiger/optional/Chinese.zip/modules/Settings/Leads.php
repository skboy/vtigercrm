<?php
/*+***********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * 简体中文语言包 - 潜在客户映射
 * 版本: 7.0.0 
 * 作者: Maie | www.maie.name
 * 更新日期: 2017-06-08
 * All Rights Reserved.
 *************************************************************************************/
$languageStrings = array(
	//Actions
	'LBL_CONVERT_LEAD_FIELD_MAPPING' => '转换潜在客户映射',
	'LBL_ORGANIZATIONS' => '客户',
	'LBL_CONTACTS' => '联系人',	
	'LBL_OPPURTUNITIES' => '销售机会',
);
$jsLanguageStrings = array(
);