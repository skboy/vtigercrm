<?php
/*+***********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * 简体中文语言包 - ModTracker
 * 版本: 6.1.0 
 * 作者: Maie | www.maie.name
 * 更新日期: 2014-08-28
 * All Rights Reserved.
 *************************************************************************************/

$languageStrings = array(
	'SINGLE_ModTracker' => '模块跟踪记录',
);
