Vtiger 7 简体中文语言包 Simplified Chinese language pack for Vtiger CRM 7.1。

基于 Vtiger 7.1.0 GA 构建 Based on Vtiger 7.1.0GA。

Vtiger CRM 6.x 由于语言字符串不同请安装另外的 6.x 系列专用语言包。

**声明：**

1.此文件内容受 vtiger CRM 的公共许可证 1.1 保护， 使用此文件表示您已默认遵守相关许可规定。 

2.此语言包遵循 知识共享署名-非商业性使用-禁止衍生-相同方式共享（创意共享3.0许可证）https://creativecommons.org/licenses/by-nc-nd/3.0/deed.zh

3. 可以免费下载使用，但请注明来源，并署名 · 非商业性使用 · 相同方式共享。

**反馈：**

欢迎加入 Vtiger CRM 爱好者 QQ 群：385434086

FAQ：http://maie.name/711.html

简体中文汉化优化及反馈，请访问：http://maie.name/tag/vtiger